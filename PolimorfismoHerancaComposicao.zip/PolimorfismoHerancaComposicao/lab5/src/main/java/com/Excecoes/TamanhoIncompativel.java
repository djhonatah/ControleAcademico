package com.Excecoes;

public class TamanhoIncompativel extends Exception{
    public TamanhoIncompativel(String mensagem) {
        super(mensagem);
    }
}