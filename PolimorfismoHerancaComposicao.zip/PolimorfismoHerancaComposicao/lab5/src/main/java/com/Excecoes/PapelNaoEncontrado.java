package com.Excecoes;

public class PapelNaoEncontrado extends Exception{
    public PapelNaoEncontrado(String mensagem) {
        super(mensagem);
    }
}
