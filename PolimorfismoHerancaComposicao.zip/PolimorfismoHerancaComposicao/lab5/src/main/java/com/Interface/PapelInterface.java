package com.Interface;

public interface PapelInterface {
    public String papelAtribuido();
}
