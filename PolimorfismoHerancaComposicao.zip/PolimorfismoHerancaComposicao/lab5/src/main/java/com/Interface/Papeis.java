package com.Interface;

public enum Papeis {
    DIRETOR, ROTEIRISTA, ATOR, CAMERA, CINEGRAFISTA;
}
